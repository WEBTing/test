// 轮播图开始
new Vue({
	el:'.swiper-wrapper',
	data:{
		img1:'<img class="img" src="tupian/lunbo1.jpg"/>',
		img2:'<img class="img" src="tupian/lunbo2.jpg"/>',
		img3:'<img class="img" src="tupian/lunbo3.jpg"/>',
		img4:'<img class="img" src="tupian/lunbo4.jpg"/>',
	}
})
var swiper = new Swiper('.swiper-container', {
      centeredSlides: true,
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });
var swiper = new Swiper('.zlunbo-text',{
	  direction: 'vertical',
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
    });
var swiper = new Swiper('.zlunbo-img',{
	  direction: 'vertical',
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
    });
// 轮播图结束
//超出屏幕回到顶部出现开始
$(document).ready(function(){
	$("#return").hide();
	$(function () {
		//检测屏幕高度
		var height=$(window).height();
		//scroll() 方法为滚动事件
		$(window).scroll(function(){
			if ($(window).scrollTop()>100){
				$("#return").fadeIn(500);
			}else{
				$("#return").fadeOut(500);
				}
		});
	});
});
//超出屏幕回到顶部出现结束
// 缓慢回到顶部开始
window.onload = function() {
var oRtn = document.getElementById('return');
var timer = null;
var flag = true;
oRtn.onclick = function() {
move();
}
window.onscroll = function() {
//flag为false时清除定时器，滚动条返回过程中，鼠标滚动使flag为false，返回中断停止  
if(!flag) {
clearInterval(timer);
}
flag = false;
}
function move() {
clearInterval(timer);
timer = setInterval(function() {
var scoll = document.documentElement.scrollTop || document.body.scrollTop;
var speed = Math.floor(-scoll / 10);
flag = true;
document.documentElement.scrollTop = document.body.scrollTop = scoll + speed;
if(scoll == 0) {
clearInterval(timer);
}
}, 30)
}
};
// 缓慢回到顶部结束
//跳转
$("#tiao").on("touchend",function(){
  window.location.href="shangpin.html" ;  
})


