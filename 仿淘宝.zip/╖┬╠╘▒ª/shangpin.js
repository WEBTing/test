var swiper = new Swiper('.swiper-container', {
      pagination: {
        el: '.swiper-pagination',
        type: 'fraction',
      },
      loop: true,
});
function getdom(a){
	return document.querySelectorAll(a)
};
var fenxiang = getdom('.fenxiang')[0];
fenxiang.onclick=function(){
	layer.open({
    content: '此功能需要访问客户端才能使用奥！'
    ,btn: ['下载手机淘宝', '逛逛别的']
    ,style:'width:50%;'
    ,yes: function(index){
      window.location.href="https://www.baidu.com/"
    }
  });
};
var xuanze=getdom('#xuanze')[0];
xuanze.onclick=function(){
	var pageii = layer.open({
  type: 1,
  content: '<div class="content"><div class="first"><img src="like-img/little.jpg"/><div class="top-text"><div class="money-price">￥30-56.4</div><div class="kucun">库存：165645</div><div class="kucun">请选择颜色分类</div></div></div><div class="fenlei">颜色分类</div><ul class="yangshi"><li>欧式花叶纹(最大款一套3个)</li><li>镜子款（1套3个）</li><li>车轮(1套3个)</li></ul><div class="shuliang">购买数量<div class="jiajian"><span class="jian">-</span><input name="shu" class="shu" id="shuzi" value="1"/><span id="jia">+</span></div></div><div class="bottom1"><div class="bottom-five add"><span>加入购物车</span></div><div class="bottom-five buy"><span>立即购买</span></div></div></div>',
  anim: 'up',
  style: 'position:fixed; left:0; bottom:0; width:100%; height:80%; border-radius: 1rem 1rem 0 0;-webkit-animation-duration: .5s; animation-duration: .5s;'
});	
	var jia=getdom('.jia')[0];
	var shuzi=getdom('#shuzi')[0];
	parent.jia.addEventListener('touchstart',function(){
			return shuzi.value=parseInt(shuzi.value)+1;
	});
	var jian=getdom('.jian')[0];
	jian.addEventListener('touchstart',function(){
	if(shuzi.value==1){}
	else{
		return shuzi.value=parseInt(shuzi.value)-1;				
		}	
	});
	$(".yangshi li").on("touchstart",function(){
		var count=$(this).index();
		$(".yangshi li").eq(count).addClass("on").siblings("li").removeClass("on");
	})
}
$(".tit li").on("touchstart",function(){
		var count=$(this).index();
		$(".tit li").eq(count).addClass("on").siblings("li").removeClass("on");
		$(".con li").eq(count).show().siblings("li").hide();
})
