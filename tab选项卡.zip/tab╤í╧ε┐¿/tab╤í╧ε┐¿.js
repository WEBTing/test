//主函数部分========================================
function tab(op_ul,opc_ul,op_lis,opc_lis,op_is,op_back,op_add,cn){
	var arr = [],
		tit_ul = getDom(op_ul)[0],//标题ul
		con_ul = getDom(opc_ul)[0],//内容ul
		clo_is = getDom(op_is),//关闭
		tit_lis = getDom(op_lis),//标题li
		con_lis = getDom(opc_lis),//内容li
		back_div = getDom(op_back)[0],
		add_div = getDom(op_add)[0];
tit_ul.onclick=function(e){

	if(e.target.nodeName == 'LI'){
		var count=getIndex(e.target);
		for(let j=0;j<con_lis.length;j++){
			if(count==j){
				if(!hasclass(tit_lis[count],"on")){
					addclass(tit_lis[count],"on");
				}
				con_lis[count].style.display='block';
				}
				else{
				removeclass(tit_lis[j],'on');
				con_lis[j].style.display='none';
			}
		}
	}
	else if(e.target.className=='col'){
		var i=getIndex(e.target.parentNode);
		li=e.target.parentNode;
		arr.push(i);//点击获取
		addclass(li,'hide');
		addclass(con_lis[i],'hide');
		for(let j=0;j<tit_lis.length;j++){
			if(hasclass(tit_lis[i],'on')){
			if(!hasclass(tit_lis[j],'hide')){
				addclass(tit_lis[j],'on');
				con_lis[j].style.display='block';
				break;
			}
		}
	}
}
}
//撤销功能
back_div.onclick=function(){
	var count=arr.pop();
	removeclass(tit_lis[count],'hide');
	removeclass(con_lis[count],'hide');
	for(let j=0;j<tit_lis.length;j++){
		if(j==count){
			addclass(tit_lis[count],'on');
			tit_lis[count].style.display='block';
			con_lis[count].style.display='block';
		}
		else{
			removeclass(tit_lis[j],'on');
			con_lis[j].style.display='none';
		}
	}
}
//新增功能
add_div.onclick=function(){
	var titli = document.createElement('li');
	titli.innerHTML='新的标题<i class="col">×</i>';
	tit_ul.appendChild(titli);
	var conli = document.createElement('li');
	conli.innerHTML='新的内容';
	con_ul.appendChild(conli);
	clo_is = getDom(op_is);//更新关闭
	tit_lis = getDom(op_lis);//更新标题li
	con_lis = getDom(opc_lis);//更新内容li
}
}
//分函数部分===================================
/*获取元素getDom,dom-id名称*/
function getDom(dom){
	return document.querySelectorAll(dom);
}
/*hasclass,判断有没有class=on*/
function hasclass(dom,cn){
	var str=dom.className,fg=false;
	var brr=str.split(' ');
	brr.forEach(function(value){
		if(value==cn){
			fg=true;
		}
	})
	return fg;
}
//addclass,加一个class
function addclass(dom,cn){
	var temp='';
	if(!hasclass(dom)){
		temp=' ';
	}
	return dom.className=dom.className+temp+cn;
}
//removeclass,移除一个class
function removeclass(dom,cn){
	var str=dom.className,arr=[];
	var brr=str.split(' ');
	brr.forEach(function(value){
		if(value!=cn){
			arr.push(value);
		}
	})
	return dom.className=arr.join(' ');
}
//获取索引值，getIndex
function getIndex(dom){
	var count = 0,that = dom;
	// 1.判断当前节点是否有前一个元素兄弟节点，如果有+1
	// 2.判断这个兄弟节点之前，是否再有一个元素兄弟节点，如果有+1
	while(that.previousElementSibling) {
		count++;
		that = that.previousElementSibling
	}
	return count;
}
