Page({
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  } 
})
