//logs.js
const util = require('../../utils/util.js')

Page({
  // 初始化数据
  data: {
    score: 0,
    maxscore: 0,
    ground: [],
    rows: 28,
    cols: 22,
    snake: [],
    food: [],
    startx: 0,
    starty: 0,
    endx: 0,
    endy: 0,
    direction: '',
    modalHidden: true,
    timer: ''
  },
  onLoad: function () {
    var maxscore = wx.getStorageInfoSync('maxscore');
    if (!maxscore) maxscore = 0;
    this.setData({
      maxscore: this.data.maxscore
    });
    this.initGround(this.data.rows, this.data.cols);//初始化操场
    this.initSnake(3);//初始化蛇的长度为3
    this.creatFood();//初始化食物
    this.move();//移动
  },
  //操场
  initGround: function (rows, cols) {
    for (var i = 0; i < rows; i++) {
      var arr = [];
      this.data.ground.push(arr);
      for (var j = 0; j < cols; j++) {
        this.data.ground[i].push(0);
      }
    }
  },
  //蛇
  initSnake: function (len) {
    for (var i = 0; i < len; i++) {
      this.data.ground[0][i] = 1;//蛇是灰色
      this.data.snake.push([0, i]);
    }
  },
  //计分
  storeScore: function () {
    if (this.data.score > this.data.maxscore) {
      this.setData({
        maxscore: this.data.score
      });
      wx.setStorageSync('maxscore', this.data.maxscore);
    }
  },
  //创造食物
  creatFood: function () {
    var x = Math.floor(Math.random() * 27 + 1);
    var y = Math.floor(Math.random() * 21 + 1);
    this.data.ground[x][y] = 2;//食物为绿色
    this.setData({
      ground: this.data.ground,
      food: [x, y]
    });
  },
  //移动
  move: function () {
    var that = this;
    this.data.timer = setInterval(function () {
      that.changeDirection(that.data.direction);
      that.setData({
        ground: that.data.ground
      });
    }, 400)
  },
  tapStart: function (event) {
    this.setData({
      startx: event.touches[0].pageX,//触点坐标获取
      starty: event.touches[0].pageY
    })
  },
  tapMove: function (event) {
    this.setData({
      endx: event.touches[0].pageX,
      endy: event.touches[0].pageY
    })
  },
  tapEnd: function (event) {
    var heng = (this.data.endx) ? (this.data.endx - this.data.startx) : 0;
    var shu = (this.data.endy) ? (this.data.endy - this.data.starty) : 0;
    if (Math.abs(heng) > 5 || Math.abs(shu) > 5) {
      var direction = (Math.abs(heng) > Math.abs(shu)) ? this.computeDir(1, heng) : this.computeDir(0, shu);
      //如果方向为左 则不能直接向右移动
      switch (direction) {
        case 'left':
          if (this.data.direction == 'right') return;
          break;
        case 'right':
          if (this.data.direction == 'left') return;
          break;
        case 'top':
          if (this.data.direction == 'bottom') return;
          break;
        case 'bottom':
          if (this.data.direction == 'top') return;
          break;
        default:
      }
      this.setData({
        startx: 0,
        starty: 0,
        endx: 0,
        endy: 0,
        direction: direction
      })
    }
  },
  //判断横着走（左右）还是竖着走（上下）
  computeDir: function (heng, num) {
    if (heng) return (num > 0) ? 'right' : 'left';
    return (num > 0) ? 'bottom' : 'top';
  },
  //改变方向
  changeDirection: function (dir) {
    switch (dir) {
      case 'left':
        return this.changeLeft();
        break;
      case 'right':
        return this.changeRight();
        break;
      case 'top':
        return this.changeTop();
        break;
      case 'bottom':
        return this.changeBottom();
        break;
      default: '出错'
    }
  },
  //检查蛇移动过程
  checkGame: function (snakeTAIL) {
    var arr = this.data.snake;
    var len = this.data.snake.length;
    var snakeHEAD = arr[len - 1];
    //蛇头碰到边界--输
    if (snakeHEAD[0] < 0 || snakeHEAD[0] >= this.data.rows || snakeHEAD[1] < 0 || snakeHEAD[1] >= this.data.cols) {
      clearInterval(this.data.timer)
      this.setData({
        modalHidden: false,
      });
    }
    //蛇碰到自己--输
    for (var i = 0; i < len - 1; i++) {
      if (arr[i][0] == snakeHEAD[0] && arr[i][1] == snakeHEAD[1]) {
        clearInterval(this.data.timer)
        this.setData({
          modalHidden: false,
        });
      }
    }
    //蛇碰到食物--长度加1,分数加10
    if (snakeHEAD[0] == this.data.food[0] && snakeHEAD[1] == this.data.food[1]) {
      arr.unshift(snakeTAIL)//头部添加一个
      this.setData({
        score: this.data.score + 10
      });
      this.storeScore();
      this.creatFood();
    }
  },
  changeTop: function () {

    var arr = this.data.snake;
    var len = this.data.snake.length;
    var snakeHEAD = arr[len - 1][1];
    var snaketail = arr[0];
    var ground = this.data.ground;
    ground[snaketail[0]][snaketail[1]] = 0;
    for (var i = 0; i < len - 1; i++) {
      arr[i] = arr[i + 1];
    };

    var x = arr[len - 1][0] - 1;
    var y = arr[len - 1][1];
    arr[len - 1] = [x, y];
    this.checkGame(snakeTAIL);
    for (var i = 1; i < len; i++) {
      ground[arr[i][0]][arr[i][1]] = 1;
    }
    this.setData({
      ground: ground,
      snake: arr
    });

    return true;
  },
  changeBottom: function () {

    var arr = this.data.snake;
    var len = this.data.snake.length;
    var snakeHEAD = arr[len - 1];
    var snakeTAIL = arr[0];
    var ground = this.data.ground;

    ground[snakeTAIL[0]][snakeTAIL[1]] = 0;
    for (var i = 0; i < len - 1; i++) {
      arr[i] = arr[i + 1];
    };
    var x = arr[len - 1][0] + 1;
    var y = arr[len - 1][1];
    arr[len - 1] = [x, y];
    this.checkGame(snakeTAIL);
    for (var i = 1; i < len; i++) {
      ground[arr[i][0]][arr[i][1]] = 1;
    }
    this.setData({
      ground: ground,
      snake: arr
    });
    return true;
  },
  changeLeft: function () {

    var arr = this.data.snake;
    var len = arr.length;
    var snakeHEAD = arr[len - 1][1];
    var snakeTAIL = arr[0];
    var ground = this.data.ground;
    ground[snakeTAIL[0]][snakeTAIL[1]] = 0;
    for (var i = 0; i < len - 1; i++) {
      arr[i] = arr[i + 1];
    };

    var x = arr[len - 1][0];
    var y = arr[len - 1][1] - 1;
    arr[len - 1] = [x, y];
    this.checkGame(snakeTAIL);
    for (var i = 1; i < len; i++) {
      ground[arr[i][0]][arr[i][1]] = 1;
    }

    this.setData({
      ground: ground,
      snake: arr
    });

    return true;
  },
  changeRight: function () {

    var arr = this.data.snake;
    var len = this.data.snake.length;
    var snakeHEAD = arr[len - 1][1];
    var snakeTAIL = arr[0];
    var ground = this.data.ground;
    ground[snakeTAIL[0]][snakeTAIL[1]] = 0;
    for (var i = 0; i < len - 1; i++) {
      arr[i] = arr[i + 1];
    };

    var x = arr[len - 1][0];
    var y = arr[len - 1][1] + 1;
    arr[len - 1] = [x, y];
    this.checkGame(snakeTAIL);
    for (var i = 1; i < len; i++) {
      ground[arr[i][0]][arr[i][1]] = 1;

    }

    this.setData({
      ground: ground,
      snake: arr
    });
    return true;
  },

   
  //点击确认后 回到页面 重新开始
  modalChange: function () {
    this.setData({
      score: 0,
      ground: [],
      snake: [],
      food: [],
      modalHidden: true,
      direction: ''
    })
    this.onLoad();
  }


})