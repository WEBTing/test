//==========================创建地图=============================
var level=["                                                                                ",
		"                                                                                ",
		"                                                                                ",
		"                                                                                ",
		"                                                                                ",
		"                                                                                ",
		"                                                                  xxx           ",
		"                                                   xx      xx    xx!xx          ",
		"                                    o o      xx                  x!!!x          ",
		"                                                                 xx!xx          ",
		"                                   xxxxx                          xvx           ",
		"                                                                            xx  ",
		"  xx                                      o o                                x  ",
		"  x                     o                                                    x  ",
		"  x                                      xxxxx                             o x  ",
		"  x          xxxx       o                                                    x  ",
		"  x  @       x  x                                                xxxxx       x  ",
		"  xxxxxxxxxxxx  xxxxxxxxxxxxxxx   xxxxxxxxxxxxxxxxxxxx     xxxxxxx   xxxxxxxxx  ",
		"                              x   x                  x     x                    ",
		"                              x!!!x                  x!!!!!x                    ",
		"                              x!!!x                  x!!!!!x                    ",
		"                              xxxxx                  xxxxxxx                    ",
		"                                                                                ",
		];
function Vector(x, y) {
	this.x = x;
	console.log(this.x);
	this.y = y;
}